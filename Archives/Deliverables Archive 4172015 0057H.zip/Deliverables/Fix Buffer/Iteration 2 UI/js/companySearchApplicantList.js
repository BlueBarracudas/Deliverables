    function details_popup_enter() {
        document.getElementById('popup-details').style.display='block';
        document.getElementById('fade').style.display='block';
    }
    function details_popup_exit() {
        document.getElementById('popup-details').style.display='none';
        document.getElementById('fade').style.display='none';
    }
    function appointment_popup_enter() {
        document.getElementById('popup-appointment').style.display='block';
        document.getElementById('fade').style.display='block';
    }
    function appointment_popup_exit() {
        document.getElementById('popup-appointment').style.display='none';
        document.getElementById('fade').style.display='none';
    }
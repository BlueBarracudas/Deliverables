$(document).ready(function(){

	$("#searchBtn").mouseover(function(){
		$("#searchBtn").css("background-color", "rgba(255,82,0, 0.8)");
		$("#searchBtn").css("border-color", "rgba(255,82,0, 0.8)");
	});

	$("#searchBtn").mouseout(function(){
		$("#searchBtn").css("background-color", "rgba(255,82,0, 1)");
		$("#searchBtn").css("border-color", "rgba(255,82,0, 1)");
	});

	$("#searchBtn2").mouseover(function(){
		$("#searchBtn2").css("background-color", "rgba(255,82,0, 0.8)");
		$("#searchBtn2").css("border-color", "rgba(255,82,0, 0.8)");
	});

	$("#searchBtn2").mouseout(function(){
		$("#searchBtn2").css("background-color", "rgba(255,82,0, 1)");
		$("#searchBtn2").css("border-color", "rgba(255,82,0, 1)");
	});

	$("#hire1").mouseover(function(){
		$("#hire1").css("background-color", "rgba(255,82,0, 0.8)");
		$("#hire1").css("border-color", "rgba(255,82,0, 0.8)");
	});

	$("#hire1").mouseout(function(){
		$("#hire1").css("background-color", "rgba(255,82,0, 1)");
		$("#hire1").css("border-color", "rgba(255,82,0, 1)");
	});

	$("#hire2").mouseover(function(){
		$("#hire2").css("background-color", "rgba(255,82,0, 0.8)");
		$("#hire2").css("border-color", "rgba(255,82,0, 0.8)");
	});

	$("#hire2").mouseout(function(){
		$("#hire2").css("background-color", "rgba(255,82,0, 1)");
		$("#hire2").css("border-color", "rgba(255,82,0, 1)");
	});


	$("#setAppointment1").mouseover(function(){
			$("#setAppointment1").css("background-color", "rgba(255,82,0, 0.8)");
			$("#setAppointment1").css("border-color", "rgba(255,82,0, 0.8)");
	});

	$("#setAppointment1").mouseout(function(){
		$("#setAppointment1").css("background-color", "rgba(255,82,0, 1)");
		$("#setAppointment1").css("border-color", "rgba(255,82,0, 1)");
	});




});